<?php

include_once "navbar.php";

include_once "includes/connect.inc.php";
$id = $_GET['id'];



?>