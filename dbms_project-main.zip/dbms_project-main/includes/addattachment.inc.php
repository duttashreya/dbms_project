<?php 
session_start();
include_once "connect.inc.php";

$id=$_GET['id'];
$sql="SELECT * FROM `evaluations` WHERE status=0 AND thesis_id=".$id." ORDER BY id DESC";
$res= mysqli_query($conn,$sql) or die(mysqli_error($conn));
$row=mysqli_fetch_array($res);
if (isset($_POST['submit'])) 
    {
       
        $file='';
        
   

        $files = array_filter($_FILES['profilepic']['name']); //Use something similar before processing files.
            // Count the number of uploaded files in array
            $total_count = count($_FILES['profilepic']['name']);
            // Loop through every file
            for( $i=0 ; $i < $total_count ; $i++ ) {
            //The temp file path is obtained
            $tmpFilePath = $_FILES['profilepic']['tmp_name'][$i];
            //A file path needs to be present
            if ($tmpFilePath != ""){
                //Setup our new file path
                $newFilePath = "../Docs/" . $_FILES['profilepic']['name'][$i];
                //File is uploaded to temp dir
                if(move_uploaded_file($tmpFilePath, $newFilePath)) {
                    $file=$file.'$$'.$_FILES['profilepic']['name'][$i];
                }
            }
            }

       $sid=$_SESSION['id'];
       $id=$row['id'];
            $query="UPDATE `evaluations` SET `status`=1, `attachments`='$file' WHERE id=".$id;     
   
            mysqli_query($conn,$query) or die(mysqli_error($conn));
        header("location: ../studentpage.php");
       
        
            exit();  
        
        }    
    
    
    ?>

  










