<?php
include_once "connect.inc.php";
if (isset($_POST['submit'])) 
    {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $date = mysqli_real_escape_string($conn, $_POST['date']);
        $marks = mysqli_real_escape_string($conn, $_POST['outofmarks']);
        $id = mysqli_real_escape_string($conn, $_POST['id']);


        $query="INSERT INTO `evaluations`(`thesis_id`, `name`, `date`, `outofmarks`, `status`) VALUES ($id,'$name','$date','$marks',0)";     
        var_dump($query);
        mysqli_query($conn,$query) or die(mysqli_error($conn));
        header("location: ../super_profile.php");
        exit();

        
    }


?>