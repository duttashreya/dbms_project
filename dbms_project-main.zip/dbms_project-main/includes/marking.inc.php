<?php
include_once "connect.inc.php";
if (isset($_POST['submit'])) 
    {
        $marks = mysqli_real_escape_string($conn, $_POST['marks']);
        $remarks = mysqli_real_escape_string($conn, $_POST['remark']);
        // $marks = mysqli_real_escape_string($conn, $_POST['outofmarks']);
        $id = mysqli_real_escape_string($conn, $_POST['id']);


        $query="UPDATE `evaluations` SET `marks`='$marks', `remarks`='$remarks', `status`=2 WHERE id=".$id;     
   
        mysqli_query($conn,$query) or die(mysqli_error($conn));
        header("location: ../super_profile.php");
        exit();

        
    }


?>