<?php
include_once "connect.inc.php";
// $id = $_POST['id'];
if (isset($_POST['submit'])) 
    {
        
        $marks = mysqli_real_escape_string($conn, $_POST['marks']);
        // $marks = mysqli_real_escape_string($conn, $_POST['outofmarks']);
        $id = mysqli_real_escape_string($conn, $_POST['id']);

        $sql = "SELECT * FROM evaluations WHERE thesis_id=".$id;
        var_dump($sql);
        $res=mysqli_query($conn,$sql);
        $row=mysqli_fetch_array($res);

        $query="UPDATE `thesis` SET `final_grade`='$marks', `status`=2 WHERE id=".$id;     
        var_dump($query);
        mysqli_query($conn,$query) or die(mysqli_error($conn));
        // var_dump($query);
        header("location: ../super_profile.php");
        exit();

        
    }


?>