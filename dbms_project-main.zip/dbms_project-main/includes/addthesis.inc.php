<?php 
session_start();
include_once "connect.inc.php";


if (isset($_POST['submit'])) 
    {
        
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $abstract = mysqli_real_escape_string($conn, $_POST['abstract']);
        $dept = mysqli_real_escape_string($conn, $_POST['department']);
        $supervisor = mysqli_real_escape_string($conn, $_POST['supervisor']);
        $file='';
        
   

        $files = array_filter($_FILES['profilepic']['name']); //Use something similar before processing files.
            // Count the number of uploaded files in array
            $total_count = count($_FILES['profilepic']['name']);
            // Loop through every file
            for( $i=0 ; $i < $total_count ; $i++ ) {
            //The temp file path is obtained
            $tmpFilePath = $_FILES['profilepic']['tmp_name'][$i];
            //A file path needs to be present
            if ($tmpFilePath != ""){
                //Setup our new file path
                $newFilePath = "../Docs/" . $_FILES['profilepic']['name'][$i];
                //File is uploaded to temp dir
                if(move_uploaded_file($tmpFilePath, $newFilePath)) {
                    $file=$file.'$$'.$_FILES['profilepic']['name'][$i];
                }
            }
            }

       $sid=$_SESSION['id'];
            $query="INSERT INTO `thesis`(`name`, `department`, `abstract`, `attachment`, `status`,`supervisor_name`, `student_id` ) VALUES ('$name','$dept','$abstract','$file',0,'$supervisor',$sid)";     
   
            mysqli_query($conn,$query) or die(mysqli_error($conn));
        header("location: ../notification.php");
       
        
            exit();  
        
        }    
    
    
    ?>

  










