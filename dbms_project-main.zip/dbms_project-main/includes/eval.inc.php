<?php
include_once "connect.inc.php";
$id=$_GET['id'];
$sql="UPDATE `thesis` SET `no_of_evaluations`=".$_POST['eval']." WHERE id=".$id;
// var_dump($sql);
mysqli_query($conn,$sql);

header("Location: ../super_profile.php");
exit();
?>