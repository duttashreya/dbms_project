<?php
session_start();
include_once "connect.inc.php";

$id = $_GET['id'];
// var_dump($id);
if (isset($_POST['submit'])) 
    {
        $s1 = mysqli_real_escape_string($conn, $_POST['supervisor1']);
        $s2 = mysqli_real_escape_string($conn, $_POST['supervisor2']);
        $s3 = mysqli_real_escape_string($conn, $_POST['supervisor3']);

        $sql1 = "SELECT * FROM thesis WHERE id=".$id;
        $res=mysqli_query($conn,$sql1);
        $row=mysqli_fetch_array($res);
        if(strcmp($s1,$s2)==0 || strcmp($s1,$s3)==0 || strcmp($s3,$s2)==0 
        || strcmp($s1,$row['supervisor_name'])==0 || strcmp($s2,$row['supervisor_name'])==0 || strcmp($s3,$row['supervisor_name'])==0){
            header("Location: ../panel.php?id=".$id."&error");
            exit();
        }

        $s=$s1.",".$s2.",".$s3;
        $sql = "UPDATE `thesis` SET `status`=1, `panel`='$s' WHERE id=".$id;
        mysqli_query($conn,$sql) or die(mysqli_error($conn));
        // var_dump($sql);
        header("location: ../super_profile.php");
        exit();
    }


?>