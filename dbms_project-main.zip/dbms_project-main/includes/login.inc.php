<?php
session_start();
include_once "connect.inc.php";

if(isset($_POST['submit'])) {
    
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $n=2;
    var_dump($email);  
    if(empty($email) || empty($pass)) {
      header("Location: ../login.php?login=empty");
      exit(); 
    }
    else{
         $sql="SELECT * FROM admin WHERE email='$email';"; 
         $result=mysqli_query($conn,$sql)or die("connection failed");
        //  var_dump($sql);
         
         $sql1="SELECT * FROM supervisor WHERE flag=1 AND email='$email';"; 
         $result1=mysqli_query($conn,$sql1)or die("connection failed");
        //  var_dump($sql1);

         $sql2="SELECT * FROM student WHERE flag=1 AND email='$email';"; 
         $result2=mysqli_query($conn,$sql2)or die("connection failed");
        if($row = mysqli_fetch_assoc($result)) {
            echo "1";
            // Dehashing the password
            $hashedPassCheck = password_verify($pass, $row['password']);
            if($hashedPassCheck == true) {
                $_SESSION['privilege'] = "admin";
                $_SESSION['id'] = $row['id'];
                header("Location: ../adminpage.php");
                exit();

                }else{
                    header("Location: ../login.php?login=error");
                    exit();
                }
    
            }
        elseif($row1 = mysqli_fetch_assoc($result1)){
            // var_dump($row1);
            $hashedPassCheck = password_verify($pass, $row1['password']);
          
            if($hashedPassCheck == true) {
                
                $_SESSION['privilege'] = "supervisor";
                $_SESSION['id'] = $row1['id'];
                $_SESSION['name'] = $row1['name'];
                // $_SESSION['parent'] = $row1['parent'];
                // $_SESSION['contact'] = $row1['contact'];
                // $_SESSION['email'] = $row1['username'];
               
                header("Location: ../index.php");
                exit();
           
                }
                else{
                    header("Location: ../login.php?login=error");
                    exit();
                }
    }
    elseif($row2 = mysqli_fetch_assoc($result2)){
        var_dump($row2);
        $hashedPassCheck = password_verify($pass, $row2['password']);
   
        if($hashedPassCheck == true) {
            $_SESSION['privilege'] = "student";
            $_SESSION['id'] = $row2['id'];
            $_SESSION['name'] = $row2['name'];
            // $_SESSION['parent'] = $row1['parent'];
            // $_SESSION['contact'] = $row1['contact'];
            // $_SESSION['email'] = $row1['username'];
           
            header("Location: ../index.php");
            exit();
       
            }
            else{
                header("Location: ../login.php?login=error");
                exit();
            }
}
    else{
        header("Location: ../login.php?login=error");
        exit();
    }
}
}
else{
    header("Location: ../login.php");
    exit();
}
?>
