<?php
session_start();
include_once "connect.inc.php";
if (isset($_POST['submit'])) 
    {

        #Treat user input as text and not as code
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $department = mysqli_real_escape_string($conn, $_POST['department']);
        $roll = mysqli_real_escape_string($conn, $_POST['roll']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);


        
        // var_dump($department);
        //var_dump($username);

        if(empty($name) ||empty($email) ) 
        {
            header("Location: ../register.php?signup=empty");
            exit();
        }
        elseif(!preg_match("/^[a-zA-Z ]*$/", $name) || !preg_match("/^[a-zA-Z ]*$/", $department) ){
            // Check if input characters are Valid i.e if they only contain a-z and A-Z
            header("Location: ../register.php?signup=invalid");
            exit();
        }
        else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Check if email is Valid
            header("Location: ../register.php?signup=email");
            exit();
        }
        else
        {
            $sql = "SELECT * FROM student WHERE email='$email';";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($result);
            if($resultCheck > 0)
            {
                header("Location: ../register.php?signup=taken");
                exit();
            }else
            {
               // $pass=bin2hex(random_bytes(4));
                $hashedPass = password_hash($password, PASSWORD_DEFAULT);
                $sql1="INSERT INTO student (`name`, `email`, `password`, `department`,`flag`,`roll`)
                VALUES ('$name','$email','$hashedPass','$department',0,'$roll');";
                mysqli_query($conn, $sql1) or die(mysqli_error($conn));
                
                header("Location: ../index.php");
                exit();
            }

        }
    }
    else if (isset($_POST['fsubmit'])) 
    {

        #Treat user input as text and not as code
        $name = mysqli_real_escape_string($conn, $_POST['fname']);
        $email = mysqli_real_escape_string($conn, $_POST['femail']);
        $department = mysqli_real_escape_string($conn, $_POST['fdepartment']);
        $password = mysqli_real_escape_string($conn, $_POST['fpassword']);
        var_dump($name);
        var_dump($email);

        if(empty($name) ||empty($email) ) 
        {
            header("Location: ../register.php?signup=empty");
            exit();
        }
        elseif(!preg_match("/^[a-zA-Z ]*$/", $name) || !preg_match("/^[a-zA-Z ]*$/", $department) ){
            // Check if input characters are Valid i.e if they only contain a-z and A-Z
            header("Location: ../register.php?signup=invalid");
            exit();
        }
        else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Check if email is Valid
            header("Location: ../register.php?signup=email");
            exit();
        }
        else
        {
            $sql = "SELECT * FROM supervisor WHERE email='$email';";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($result);
            if($resultCheck > 0)
            {
                header("Location: ../register.php?signup=taken");
                exit();
            }else
            {
               // $pass=bin2hex(random_bytes(4));
                $hashedPass = password_hash($password, PASSWORD_DEFAULT);
                $sql1="INSERT INTO supervisor (`name`, `email`, `password`, `department`,`flag`)
                VALUES ('$name','$email','$hashedPass','$department',0);";
                mysqli_query($conn, $sql1) or die(mysqli_error($conn));
                // Now redirect the user
                //header("Location: ../rmail.php?email=".$username);
                header("Location: ../index.php");
                exit();
            }

        }
    }
    
    
    
    else
     {
        // If someone just loads the url without submitting data
        header("Location: ../register.php");
        exit();
      }

    
?>