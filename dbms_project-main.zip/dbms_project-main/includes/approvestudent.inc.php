<?php
include_once "connect.inc.php";
$id=$_GET['id'];
$sql="UPDATE  `student` SET `flag`=1 WHERE id=".$id;
$res=mysqli_query($conn,$sql);
header("Location: ../approvestudent.php");
exit();
?>