<?php
session_start();
include_once "connect.inc.php";
if (isset($_POST['submit'])) 
    {
        $topic = mysqli_real_escape_string($conn, $_POST['topic']);
        $keyword = mysqli_real_escape_string($conn, $_POST['keyword']);
        $supervisor = mysqli_real_escape_string($conn, $_POST['supervisor']);
        $abstract = mysqli_real_escape_string($conn, $_POST['abstract']);


        
            $sid=$_SESSION['id'];
            $sql2="SELECT * FROM student WHERE flag=1 AND id=".$sid;
            
         $result2=mysqli_query($conn,$sql2)or die("connection failed");
         $row2=mysqli_fetch_array($result2);
         $dept=$row2['department'];
            $query="INSERT INTO `thesis`(`name`, `department`, `keyword`, `status`,`supervisor_name`, `student_id`, `abstract` ) VALUES ('$topic','$dept','$keyword',0,'$supervisor',$sid,'$abstract')";     
            // var_dump($query);
            mysqli_query($conn,$query) or die(mysqli_error($conn));
            header("location: ../studentpage.php");
       

        
    }


?>