<?php

include_once "connect.inc.php";
$id=$_GET['id'];
$sql = "DELETE FROM `thesis` WHERE `id`=".$id;
$res=mysqli_query($conn,$sql);
header("Location: ../super_profile.php");
exit();
?>